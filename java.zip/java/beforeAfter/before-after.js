const container = document.querySelector('.container');
document.querySelector('.slider').addEventListener('input', (e) => {
  container.style.setProperty('--position', `${e.target.value}%`);
})

const container22 = document.querySelector('.container22');
document.querySelector('.slider22').addEventListener('input', (e) => {
  container22.style.setProperty('--position', `${e.target.value}%`);
})


const container23 = document.querySelector('.container23');
document.querySelector('.slider23').addEventListener('input', (e) => {
  container23.style.setProperty('--position', `${e.target.value}%`);
})

const container24 = document.querySelector('.container24');
document.querySelector('.slider24').addEventListener('input', (e) => {
  container24.style.setProperty('--position', `${e.target.value}%`);
})



